﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CP.CW1._8996
{
    public class Gate
    {
        public string name = "";
        public bool isAvailable = true;

        public Gate(string name)
        {
            this.name = name;
        }
    }

    public partial class Form1 : Form
    {
        SemaphoreSlim gSlim = new SemaphoreSlim(10, 10);
        SemaphoreSlim rSlim = new SemaphoreSlim(3, 3);
        ReaderWriterLock rwlock = new ReaderWriterLock();
        CountdownEvent cde = new CountdownEvent(20);

        object obj = new object();

        WCFService.Service1Client client = new WCFService.Service1Client();


        List<Gate> gates;

        public Form1()
        {
            InitializeComponent();
            gates = new List<Gate>() {
                new Gate("gate111"),
                new Gate("gate222"),
                new Gate("gate333"),
                new Gate("gate444"),
                new Gate("gate555"),
                new Gate("gate666"),
                new Gate("gate777"),
                new Gate("gate888"),
                new Gate("gate999"),
                new Gate("gate074"),
            };
            File.WriteAllText("output.txt", "");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            Thread thr = new Thread(() =>
            {
                loadFlights();
            });
            thr.Start();

            Thread secThread = new Thread(() =>
            {
                cde.Wait();
                invoke(() =>
                {
                    button1.Enabled = true;
                    MessageBox.Show("All flights have finished!");
                });

                cde.Reset();
            });
            secThread.Start();
        }

        void loadFlights()
        {
            int length = dataGridView1.Rows.Count;

            // Read flights data from txt file
            string[] dataLines = File.ReadAllLines("input.txt");
            

            for (int i = 0; i < dataLines.Length; i++)
            {
                // lock shared object dataGridView
                lock (obj)
                {
                    string rawData = dataLines[i];
                    string[] flight = rawData.Split(',');

                    for (int j = 0; j < flight.Length; j++)
                    {
                        // set departure date with 3 hours extra
                        if (j == 2) flight[j] = DateTime.Now.AddHours(3).ToString();
                    }
                    invoke(() =>
                    {
                        // display on dashboard
                        dataGridView1.Rows.Add(flight);
                        // display log on listbox
                        listBox1.Items.Add(String.Format("{0} is check-in", flight[0]));
                    });

                    // Handle flight
                    Thread thrd = new Thread((object idx) =>
                    {
                        startFlight((int)idx);
                    });
                    thrd.Start(length + i);
                }
            }
        }

        void startFlight(int index)
        {
            // Wait for gates to be available
            gSlim.Wait();

            DataGridViewRow row = dataGridView1.Rows[index];
            Gate availableGate = gates.Find(g => g.isAvailable);

            // set flight status "Boarding"

            row.Cells[3].Value = "Boarding";
            row.Cells[3].Style.BackColor = Color.Yellow;
            row.Cells[2].Value = DateTime.Now.AddHours(1).ToString();
            row.Cells[4].Value = availableGate.name;
            availableGate.isAvailable = false;



            invoke(() => {
                listBox1.Items.Add(String.Format("{0} Boarding", row.Cells[0].Value));
            });

            Thread.Sleep(random());

            // set flight status "Ready-to-take-off"
            row.Cells[3].Value = "Ready-to-take-off";
            row.Cells[3].Style.BackColor = Color.Orange;
            row.Cells[2].Value = DateTime.Now.AddMinutes(15).ToString();


            invoke(() => {
                listBox1.Items.Add(String.Format("{0} is Ready-to-take-off", row.Cells[0].Value));
                listBox1.Items.Add(String.Format("Waiting for ranaway car"));
            });

            Thread.Sleep(random());

            rSlim.Wait();
            // Status Takeoff
            row.Cells[2].Value = DateTime.Now.ToString();
            row.Cells[3].Value = "Take-off";
            row.Cells[3].Style.BackColor = Color.Green;

            invoke(() => {
                listBox1.Items.Add(String.Format("{0} is Take-off", row.Cells[0].Value));
            });

            // lock access to file while writing
            rwlock.AcquireWriterLock(Timeout.Infinite);

            // Saving to output.txt
            File.AppendAllText("output.txt",
                String.Format("{0},{1},{2},{3},{4}\n",
                    row.Cells[0].Value.ToString(),
                    row.Cells[1].Value.ToString(),
                    row.Cells[2].Value.ToString(),
                    row.Cells[3].Value.ToString(),
                    row.Cells[4].Value.ToString()));

            // unlock access to file
            rwlock.ReleaseWriterLock();

            // Send data to WCF
             string apiData = client.SaveFlightData(
                row.Cells[0].Value.ToString(),
                row.Cells[1].Value.ToString(),
                row.Cells[2].Value.ToString(),
                row.Cells[3].Value.ToString(),
                row.Cells[4].Value.ToString());

            invoke(() => {
                listBox1.Items.Add(String.Format("{0} has finished.", row.Cells[0].Value));
                listBox1.Items.Add(String.Format("API Data: {0}", apiData));
            });

            availableGate.isAvailable = true;

            // signal that flight has finished
            cde.Signal();
            // release that gate is available for next flight
            gSlim.Release();
            // signal that ranaway is available for next flight
            rSlim.Release();
        }

        void invoke(Action func)
        {
            Invoke(
                new MethodInvoker(
                    () => {
                        func();
                    }
                )
            );
        }

        int random()
        {
            return new Random().Next(10, 50) * 100;
        }
    }
}
